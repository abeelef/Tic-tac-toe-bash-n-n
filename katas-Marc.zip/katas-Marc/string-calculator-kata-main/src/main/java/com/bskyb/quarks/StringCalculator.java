package com.bskyb.quarks;

import java.util.ArrayList;
import java.util.List;

public class StringCalculator {

    // Variable per acumular la suma final
    int numeros;

    public int add(String numbers) {

        // Step 1 — Si l'string és buit, retornem 0
        if (numbers.isEmpty()) {
            return 0;
        }

        // Llista per emmagatzemar delimitadors
        List<String> delimitadores = new ArrayList<>();

        // Cos principal del string, pot contenir només els nombres
        String cuerpo = numbers;

        // Step 4, 7, 8i 9 — Tractar delimitadors personalitzats
        if (numbers.startsWith("//")) {
            // Troba la posició del salt de línia que separa el "header" dels nums
            int endHeader = numbers.indexOf("\n");

            // Agafa el header entre "//" i el salt de línia
            String header = numbers.substring(2, endHeader);

            // Si el header conté [], vol dir que tenim delimitadors de longitud variable o múltiples
            if (header.contains("[") && header.contains("]")) {
                // Step 7, 8, 9 — Suport per múltiples delimitadors i de longitud > 1
                int i = 0;
                while (i < header.length()) {
                    int start = header.indexOf("[", i);
                    int end = header.indexOf("]", i);

                    // Si no es troba cap més [ ] es para el bucle
                    if (start == -1 || end == -1) break;

                    // Afegeix el delimitador trobat a la llista
                    String delim = header.substring(start + 1, end);
                    delimitadores.add(delim);

                    // Avança l'índex
                    i = end + 1;
                }
            } else {
                // Step 4 — Cas senzill amb un delimitador personalitzat de 1 caràcter
                delimitadores.add(header);
            }

            // El cos real dels números comença després del salt de línia
            cuerpo = numbers.substring(endHeader + 1);

        } else {
            // Step 1 i 2 — Si no hi ha cap header, el delimitador per defecte és ","
            delimitadores.add(",");
        }

        // Step 3 — Afegim el salt de línia com a delimitador vàlid addicional
        delimitadores.add("\n");

        // Reemplacem tots els delimitadors per una coma per poder fer l'ultim aps
        for (String delim : delimitadores) {
            cuerpo = cuerpo.replace(delim, ",");
        }

        // Separem tots els valors numèrics
        String[] partes = cuerpo.split(",");

        // Inicialitzem la suma i una llista per emmagatzemar valors negatius
        numeros = 0;
        List<Integer> negativos = new ArrayList<>();

        // Iterem per cada part del string
        for (String part : partes) {
            if (part.isEmpty()) continue;

            int num = Integer.parseInt(part);

            // Step 5 — Si és negatiu, el guardem per llançar l’excepció després
            if (num < 0) {
                negativos.add(num);
            }
            // Step 6 — Ignorem valors superiors a 1000
            else if (num <= 1000) {
                numeros += num;
            }
        }

        // Step 5 — Si hi ha negatius, llencem una excepció amb tots
        if (!negativos.isEmpty()) {
            throw new IllegalArgumentException(
                    "Negatives not allowed: " + negativos.toString().replaceAll("[\\[\\]]", "")
            );
        }

        // Retornem la suma final de tots els valors vàlids
        return numeros;
    }
}

