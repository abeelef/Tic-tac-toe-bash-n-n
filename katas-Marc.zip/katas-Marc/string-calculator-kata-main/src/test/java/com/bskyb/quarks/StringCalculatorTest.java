package com.bskyb.quarks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StringCalculatorTest {

    @Test
    void emptyStringReturnsZero() {
        StringCalculator calc = new StringCalculator();
        assertEquals(0, calc.add(""));
    }

    @Test
    void singleNumberReturnsValue() {
        StringCalculator calc = new StringCalculator();
        assertEquals(7, calc.add("7"));
    }

    @Test
    void multipleNumberReturnsValue() {
        StringCalculator calc = new StringCalculator();
        assertEquals(9, calc.add("7,2"));
    }

    @Test
    void multipleNumbersAreAdded() {
        StringCalculator calc = new StringCalculator();
        assertEquals(10, calc.add("1,2,3,4"));
    }

    @Test
    void numbersSeparatedByCommaOrNewlineAreAdded() {
        StringCalculator calc = new StringCalculator();
        assertEquals(6, calc.add("1\n2,3"));
    }

    @Test
    void customDelimiterIsSupported() {
        StringCalculator calc = new StringCalculator();
        assertEquals(3, calc.add("//;\n1;2"));
    }

    @Test
    void negativeNumbersThrowException() {
        StringCalculator calc = new StringCalculator();
        IllegalArgumentException thrown =
                org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> {
                    calc.add("1,-2,3,-4");
                });
        assertTrue(thrown.getMessage().contains("Negatives not allowed: -2, -4"));
    }

    @Test
    void numbersGreaterThan1000AreIgnored() {
        StringCalculator calc = new StringCalculator();
        assertEquals(2, calc.add("2,1001"));
    }

    @Test
    void delimitersCanBeLongerThanOneChar() {
        StringCalculator calc = new StringCalculator();
        assertEquals(6, calc.add("//[***]\n1***2***3"));
    }

    @Test
    void multipleDelimitersAreSupported() {
        StringCalculator calc = new StringCalculator();
        assertEquals(6, calc.add("//[*][%]\n1*2%3"));
    }

    @Test
    void multipleDelimitersWithMultipleCharactersAreSupported() {
        StringCalculator calc = new StringCalculator();
        assertEquals(6, calc.add("//[**][%%]\n1**2%%3"));
    }
}
