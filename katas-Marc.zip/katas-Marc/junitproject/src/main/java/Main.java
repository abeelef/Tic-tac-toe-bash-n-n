public class Main {

    public static void main(String[] args){
        //double salary = 1000;
        //System.out.println(MoneyUtil.format(salary));
        Game game = new Game();
        game.play();
    }
}
