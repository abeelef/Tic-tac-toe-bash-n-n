import org.junit.Assert;
import org.junit.Test;

public class MoneyUtilTest {

    @Test
    public void moneyTest(){
        String money = MoneyUtil.format(1000);
        Assert.assertEquals("$1000.00", money); //el primer es el que volem, el segon el que ens arriba
    }

    @Test
    public void negativeMoneyTest(){
        String money = MoneyUtil.format(-1000);
        Assert.assertEquals("-$1000.00", money); //el primer es el que volem, el segon el que ens arriba
    }

    @Test
    public void euroMoneyTest(){
        String money = MoneyUtil.format(-1000, "€");
        Assert.assertEquals("-€1000.00", money); //el primer es el que volem, el segon el que ens arriba
    }

    @Test(expected = IllegalArgumentException.class)
    public void notNullExceptionMoneyTest(){
        MoneyUtil.format(-1000, null);
    }
}
