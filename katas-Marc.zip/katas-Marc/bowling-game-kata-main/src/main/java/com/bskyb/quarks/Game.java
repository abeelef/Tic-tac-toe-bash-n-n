package com.bskyb.quarks;

public class Game {

    // Guardem totes les tirades que fa el jugador. Un màxim de 21 tirades (perquè en el darrer frame pot haver-hi 1 o 2 boles extra)
    private final int[] rolls = new int[21];

    //Aquest índex ens indica en quin punt de l'array estem afegint la nova tirada
    private int currentRoll = 0;

    /**
     * Registrar una tirada: quants pins han caigut en aquesta jugada.
     */
    public void roll(int pins) {
        // Afegim la tirada actual a la posició actual de l'array
        rolls[currentRoll] = pins;

        // Avancem a la següent posició per la pròxima tirada
        currentRoll++;
    }

    /**
     * Calcula la puntuació total de la partida després de jugar 10 frames.
     * @return puntuació total de la partida.
     */
    public int score() {
        int total = 0;        // Puntuació acumulada
        int frameStart = 0;   // Índex on comença cada frame (pot variar si hi ha strike)

        for (int frame = 1; frame <= 10; frame++) {

            int first = rolls[frameStart];         // Primera bola del frame
            int second = rolls[frameStart + 1];    // Segona bola del frame (pot ser 0 si hi ha strike)

            // Strike: el primer llançament tomba 10 pins
            if (first == 10) {
                int bonus1 = rolls[frameStart + 1];  // Primer bonus (tirada següent)
                int bonus2 = rolls[frameStart + 2];  // Segon bonus (següent després de l'anterior)
                total += 10 + bonus1 + bonus2;       // Strike + 2 tirades de bonus
                frameStart += 1;                     // Només hem usat una tirada per aquest frame
            }

            // Spare: la suma de dues tirades fa 10
            else if (first + second == 10) {
                int bonus = rolls[frameStart + 2];   // Bonus: la tirada següent
                total += 10 + bonus;
                frameStart += 2;                     // Hem usat dues tirades en aquest frame
            }

            // ➕ Cas normal: menys de 10 en dues tirades
            else {
                total += first + second;
                frameStart += 2;
            }
        }

        return total;
    }
}
