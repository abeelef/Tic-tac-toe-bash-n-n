package com.bskyb.quarks;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class GameTest {

    private Game game;

    @BeforeEach
    void setUp() {
        // Creem un nou joc abans de cada test
        game = new Game();
    }

    /** Test: si totes les tirades són 0, el resultat ha de ser 0. */
    @Test
    void gutterGame_allZeroes_scoreZero() {
        rollMany(20, 0);
        assertEquals(0, game.score(), "Si fas 20 tirades de 0, el resultat ha de ser 0");
    }

    /** Test: si totes les tirades són 1, el resultat ha de ser 20 (20 × 1). */
    @Test
    void allOnes_allOnes_scoreTwenty() {
        rollMany(20, 1);
        assertEquals(20, game.score(), "20 tirades de 1 punt cada una suma 20");
    }

    /** Test: un Spare: 7+3 (spare) + 4 → 7+3+4 = 14, després resta zeros = 14. */
    @Test
    void oneSpare_scoresCorrectly() {
        game.roll(7);
        game.roll(3); // Spare (suma 10 en el frame)
        game.roll(4); // Bonus del spare
        rollMany(17, 0);
        assertEquals(18, game.score(), "Spare: 10 + 4 de bonus + 4 del proper llançament = 18");
    }

    /** Test: un Strike (10) + tirades normals: 1,2 → 10+1+2 + 1+2 = 16. */
    @Test
    void oneStrike_scoresCorrectly() {
        game.roll(10); // Strike
        game.roll(1);
        game.roll(2);  // Tirades normals
        rollMany(17, 0);
        assertEquals(16, game.score(), "Strike: 10 +1+2 + després 1+2 = 16");
    }

    /** Test: partida perfecta amb 12 strikes → puntuació 300. */
    @Test
    void perfectGame_scoresThreeHundred() {
        rollMany(12, 10);
        assertEquals(300, game.score(), "12 strikes = puntuació perfecta (300)");
    }

    /** Test: 10 spares de 5+5, amb bola extra de 5 → 150 punts. */
    @Test
    void allSpares_scoresOneFifty() {
        for (int i = 0; i < 10; i++) {
            game.roll(5);
            game.roll(5); // Spare
        }
        game.roll(5); // Tirada extra pel 10è spare
        assertEquals(150, game.score(), "10 spares amb 5+5 i extra 5 sumen 150");
    }

    /**
     * Mètode auxiliar: fa n tirades amb el mateix nombre de pins.
     */
    private void rollMany(int n, int pins) {
        for (int i = 0; i < n; i++) {
            game.roll(pins);
        }
    }
}
