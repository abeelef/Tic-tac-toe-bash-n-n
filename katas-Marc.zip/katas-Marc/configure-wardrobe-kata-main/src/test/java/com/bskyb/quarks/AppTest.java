package com.bskyb.quarks;

import org.junit.jupiter.api.Test;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class AppTest {

    /**
     * Test per comprovar que el cost es calcula correctament amb un únic mòdul.
     */
    @Test
    void calculaCostAmbUnModul() {
        List<Integer> modulUsat = List.of(100);
        Map<Integer, Integer> preusModuls = new HashMap<>();
        preusModuls.put(100, 90);

        int costResultat = App.calcularCost(modulUsat, preusModuls);

        assertEquals(90, costResultat);
    }

    /**
     * Test per comprovar que el cost es calcula bé amb diversos mòduls.
     */
    @Test
    void calculaCostAmbDiversosModuls() {
        List<Integer> modulsUsats = List.of(50, 100, 100);
        Map<Integer, Integer> preusModuls = new HashMap<>();
        preusModuls.put(50, 59);
        preusModuls.put(100, 90);

        int costResultat = App.calcularCost(modulsUsats, preusModuls);

        assertEquals(59 + 90 + 90, costResultat);  // 239
    }

    /**
     * Test per comprovar que funciona si el mòdul té un preu però no està al conjunt habitual.
     */
    @Test
    void calculaCostAmbModulNoHabitual() {
        List<Integer> modulsUsats = List.of(60);
        Map<Integer, Integer> preusModuls = new HashMap<>();
        preusModuls.put(60, 123);

        int costResultat = App.calcularCost(modulsUsats, preusModuls);

        assertEquals(123, costResultat);
    }

    /**
     * Test per comprovar que si no hi ha cap mòdul, el cost és 0.
     */
    @Test
    void calculaCostAmbCapModul() {
        List<Integer> modulsUsats = new ArrayList<>();
        Map<Integer, Integer> preusModuls = new HashMap<>();

        int costResultat = App.calcularCost(modulsUsats, preusModuls);

        assertEquals(0, costResultat);
    }
}
