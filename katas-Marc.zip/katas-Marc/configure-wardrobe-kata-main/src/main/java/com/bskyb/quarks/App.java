package com.bskyb.quarks;

import java.util.*;

public class App {

    public static void main(String[] args) {
        int paret = 250;
        int[] modules = {50, 75, 100, 120};

        // Preus per a cada mòdul
        Map<Integer, Integer> preus = new HashMap<>();
        preus.put(50, 59);
        preus.put(75, 62);
        preus.put(100, 90);
        preus.put(120, 111);

        // Guardem totes les combinacions que sumen exactament 250
        List<List<Integer>> combinacions = new ArrayList<>();

        // Provar combinacions de fins a 5 mòduls
        for (int a : modules) {
            if (a == paret) combinacions.add(List.of(a));
            for (int b : modules) {
                if (a + b == paret) combinacions.add(List.of(a, b));
                for (int c : modules) {
                    if (a + b + c == paret) combinacions.add(List.of(a, b, c));
                    for (int d : modules) {
                        if (a + b + c + d == paret) combinacions.add(List.of(a, b, c, d));
                        for (int e : modules) {
                            if (a + b + c + d + e == paret)
                                combinacions.add(List.of(a, b, c, d, e));
                        }
                    }
                }
            }
        }

        // Mostrar totes les combinacions i el seu cost
        System.out.println("Combinacions que fan " + paret + " cm:");
        for (List<Integer> combo : combinacions) {
            int cost = calcularCost(combo, preus);
            System.out.println(combo + " → cost: " + cost + " USD");
        }

        // Trobar la combinació més barata
        List<Integer> millor = null;
        int costMillor = Integer.MAX_VALUE;
        for (List<Integer> combo : combinacions) {
            int cost = calcularCost(combo, preus);
            if (cost < costMillor) {
                costMillor = cost;
                millor = combo;
            }
        }

        // Mostrar la millor
        if (millor != null) {
            System.out.println("\nLa combinació més barata és: " + millor + " → cost: " + costMillor + " USD");
        } else {
            System.out.println("No s'ha trobat cap combinació que sumi exactament " + paret + " cm.");
        }
    }

    // Mètode per calcular el cost total d'una combinació
    public static int calcularCost(List<Integer> combo, Map<Integer, Integer> preus) {
        int suma = 0;
        for (int modul : combo) {
            suma += preus.get(modul);
        }
        return suma;
    }
}
